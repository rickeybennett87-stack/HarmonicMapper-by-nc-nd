# HarmonicMapper

HarmonicMapper is a visual harmonic detection tool designed to interpret wave-based metaphysical harmonics using a touch interface and visual color shifts.

- Built for Android using Sketchware and WebView
- Developed by Rickey Bennett
- All art and code protected under Creative Commons BY-NC-ND 4.0

## Usage

You are free to download, use, and share the app.  
You may not modify or use the code/art for commercial purposes.

## License

This project is licensed under Creative Commons BY-NC-ND 4.0.  
See the LICENSE file for details.
